package org.example.serveremulator.DTO;
public class SubjectRequest {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
